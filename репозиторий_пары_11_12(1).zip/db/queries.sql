-- =====================================================================
-- SQL-запросы для приложения ShoeShop (db/queries.sql)
-- Пара 11: авторизация, каталог, поиск/фильтр/сортировка, CRUD товаров
-- =====================================================================

USE `shoeshop`;

-- ---------------------------------------------------------------------
-- 1. Проверка количества строк после восстановления (Этап 3)
-- ---------------------------------------------------------------------
SELECT table_name, table_rows
FROM information_schema.tables
WHERE table_schema = 'shoeshop'
ORDER BY table_name;

-- ---------------------------------------------------------------------
-- 2. Авторизация пользователя (пункты 2.5, 2.6, 3.17 чек-листа)
--    Возвращает id, ФИО и роль пользователя по логину и паролю.
-- ---------------------------------------------------------------------
SELECT u.id, u.full_name, r.name AS role
FROM users u
JOIN roles r ON r.id = u.role_id
WHERE u.login = ? AND u.password = ?;

-- Тестовый пример для проверки в MySQL Workbench:
-- SELECT u.id, u.full_name, r.name AS role
-- FROM users u
-- JOIN roles r ON r.id = u.role_id
-- WHERE u.login = '94d5ous@gmail.com' AND u.password = 'uzWC67';

-- ---------------------------------------------------------------------
-- 3. Каталог товаров для Гостя, Клиента, Менеджера и Администратора
--    (пункты 2.7–2.11 чек-листа)
-- ---------------------------------------------------------------------
SELECT p.id, p.article, p.name, p.unit, p.price, p.discount, p.stock_qty,
       p.description, p.photo,
       c.name AS category, m.name AS manufacturer, s.name AS supplier
FROM products p
JOIN categories c ON c.id = p.category_id
JOIN manufacturers m ON m.id = p.manufacturer_id
JOIN suppliers s ON s.id = p.supplier_id;

-- ---------------------------------------------------------------------
-- 4. Поиск, фильтрация и сортировка товаров (пункты 3.2–3.6 чек-листа)
-- ---------------------------------------------------------------------
-- 4.1. Одновременная работа поиска по названию, фильтра по поставщику
--      и сортировки по остатку на складе (пункт 3.6 чек-листа):
SELECT p.id, p.article, p.name, p.unit, p.price, p.discount, p.stock_qty,
       p.description, p.photo,
       c.name AS category, m.name AS manufacturer, s.name AS supplier
FROM products p
JOIN categories c ON c.id = p.category_id
JOIN manufacturers m ON m.id = p.manufacturer_id
JOIN suppliers s ON s.id = p.supplier_id
WHERE p.name LIKE CONCAT('%', ?, '%') AND p.supplier_id = ?
ORDER BY p.stock_qty DESC;

-- 4.2. Сортировка по количеству на складе по возрастанию/убыванию (пункты 3.2–3.3):
SELECT p.id, p.article, p.name, p.price, p.stock_qty, s.name AS supplier
FROM products p
JOIN suppliers s ON s.id = p.supplier_id
ORDER BY p.stock_qty ASC;

-- 4.3. Фильтрация только по поставщику (пункты 3.4–3.5):
SELECT p.id, p.article, p.name, p.price, p.stock_qty, s.name AS supplier
FROM products p
JOIN suppliers s ON s.id = p.supplier_id
WHERE p.supplier_id = ?;

-- ---------------------------------------------------------------------
-- 5. Справочники для выпадающих списков формы товара (пункты 3.7, 3.10)
-- ---------------------------------------------------------------------
SELECT id, name FROM categories;
SELECT id, name FROM manufacturers;
SELECT id, name FROM suppliers;

-- ---------------------------------------------------------------------
-- 6. Добавление и редактирование товара (пункты 3.7, 3.10, 3.12, 3.19)
-- ---------------------------------------------------------------------
-- 6.1. Добавление нового товара:
INSERT INTO products
  (article, name, unit, price, discount, stock_qty, description, photo, category_id, manufacturer_id, supplier_id)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);

-- 6.2. Открытие товара для редактирования (получить все поля по id):
SELECT * FROM products WHERE id = ?;

-- 6.3. Сохранение изменений существующего товара:
UPDATE products
SET article = ?, name = ?, unit = ?, price = ?, discount = ?, stock_qty = ?,
    description = ?, photo = ?, category_id = ?, manufacturer_id = ?, supplier_id = ?
WHERE id = ?;

-- ---------------------------------------------------------------------
-- 7. Защита от удаления купленного товара (пункт 3.16 чек-листа)
-- ---------------------------------------------------------------------
-- 7.1. Предварительная проверка, присутствует ли товар в заказах:
SELECT COUNT(*) AS used_in_orders FROM prodorders WHERE product_id = ?;

-- 7.2. Удаление товара (если used_in_orders = 0; иначе СУБД вернёт ошибку FK):
DELETE FROM products WHERE id = ?;
