-- MySQL Workbench Forward Engineering
-- Скрипт создания и наполнения базы данных магазина обуви (shoeshop)

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

DROP SCHEMA IF EXISTS `shoeshop`;
CREATE SCHEMA IF NOT EXISTS `shoeshop` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `shoeshop`;

-- 1. Таблица categories
CREATE TABLE IF NOT EXISTS `shoeshop`.`categories` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

-- 2. Таблица manufacturers
CREATE TABLE IF NOT EXISTS `shoeshop`.`manufacturers` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

-- 3. Таблица suppliers
CREATE TABLE IF NOT EXISTS `shoeshop`.`suppliers` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

-- 4. Таблица roles
CREATE TABLE IF NOT EXISTS `shoeshop`.`roles` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

-- 5. Таблица orderstatus
CREATE TABLE IF NOT EXISTS `shoeshop`.`orderstatus` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

-- 6. Таблица pvz
CREATE TABLE IF NOT EXISTS `shoeshop`.`pvz` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `postcode` CHAR(6) NOT NULL,
  `city` VARCHAR(30) NOT NULL,
  `street` VARCHAR(30) NOT NULL,
  `house` VARCHAR(5) NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

-- 7. Таблица users
CREATE TABLE IF NOT EXISTS `shoeshop`.`users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `full_name` VARCHAR(60) NOT NULL,
  `login` VARCHAR(50) NOT NULL,
  `password` VARCHAR(30) NOT NULL,
  `role_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_users_roles_idx` (`role_id` ASC) VISIBLE,
  CONSTRAINT `fk_users_roles`
    FOREIGN KEY (`role_id`)
    REFERENCES `shoeshop`.`roles` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

-- 8. Таблица products
CREATE TABLE IF NOT EXISTS `shoeshop`.`products` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `article` VARCHAR(10) NOT NULL,
  `name` VARCHAR(50) NOT NULL,
  `unit` VARCHAR(10) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `discount` INT NOT NULL,
  `stock_qty` INT NOT NULL,
  `description` VARCHAR(255) NULL DEFAULT NULL,
  `photo` VARCHAR(50) NULL DEFAULT NULL,
  `category_id` INT NOT NULL,
  `manufacturer_id` INT NOT NULL,
  `supplier_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_products_category_idx` (`category_id` ASC) VISIBLE,
  INDEX `fk_products_manufacturer_idx` (`manufacturer_id` ASC) VISIBLE,
  INDEX `fk_products_supplier_idx` (`supplier_id` ASC) VISIBLE,
  CONSTRAINT `fk_products_category`
    FOREIGN KEY (`category_id`)
    REFERENCES `shoeshop`.`categories` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_products_manufacturer`
    FOREIGN KEY (`manufacturer_id`)
    REFERENCES `shoeshop`.`manufacturers` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_products_supplier`
    FOREIGN KEY (`supplier_id`)
    REFERENCES `shoeshop`.`suppliers` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

-- 9. Таблица orders
CREATE TABLE IF NOT EXISTS `shoeshop`.`orders` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `order_date` DATETIME NOT NULL,
  `delivery_date` DATETIME NULL DEFAULT NULL,
  `pvz_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `receive_code` VARCHAR(10) NOT NULL,
  `status_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_orders_pvz_idx` (`pvz_id` ASC) VISIBLE,
  INDEX `fk_orders_users_idx` (`user_id` ASC) VISIBLE,
  INDEX `fk_orders_orderstatus_idx` (`status_id` ASC) VISIBLE,
  CONSTRAINT `fk_orders_pvz`
    FOREIGN KEY (`pvz_id`)
    REFERENCES `shoeshop`.`pvz` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_orders_users`
    FOREIGN KEY (`user_id`)
    REFERENCES `shoeshop`.`users` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_orders_orderstatus`
    FOREIGN KEY (`status_id`)
    REFERENCES `shoeshop`.`orderstatus` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

-- 10. Таблица prodorders
CREATE TABLE IF NOT EXISTS `shoeshop`.`prodorders` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `order_id` INT NOT NULL,
  `product_id` INT NOT NULL,
  `qty` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_prodorders_orders_idx` (`order_id` ASC) VISIBLE,
  INDEX `fk_prodorders_products_idx` (`product_id` ASC) VISIBLE,
  CONSTRAINT `fk_prodorders_orders`
    FOREIGN KEY (`order_id`)
    REFERENCES `shoeshop`.`orders` (`id`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_prodorders_products`
    FOREIGN KEY (`product_id`)
    REFERENCES `shoeshop`.`products` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE = InnoDB DEFAULT CHARACTER SET = utf8mb4;

-- Наполнение таблиц данными из CSV
INSERT INTO `shoeshop`.`categories` VALUES
  (1, 'Женская обувь'),
  (2, 'Мужская обувь');

INSERT INTO `shoeshop`.`manufacturers` VALUES
  (1, 'Kari'),
  (2, 'Marco Tozzi'),
  (3, 'CROSBY'),
  (4, 'Рос'),
  (5, 'Alessio Nesca'),
  (6, 'Rieker');

INSERT INTO `shoeshop`.`suppliers` VALUES
  (1, 'Kari'),
  (2, 'Обувь для вас');

INSERT INTO `shoeshop`.`roles` VALUES
  (1, 'Администратор'),
  (2, 'Менеджер'),
  (3, 'Авторизированный клиент');

INSERT INTO `shoeshop`.`orderstatus` VALUES
  (1, 'Завершен'),
  (2, 'Новый');

INSERT INTO `shoeshop`.`pvz` VALUES
  (1, '420151', 'Лесной', 'Вишневая', '32'),
  (2, '125061', 'Лесной', 'Подгорная', '8'),
  (3, '630370', 'Лесной', 'Шоссейная', '24'),
  (4, '400562', 'Лесной', 'Зеленая', '32'),
  (5, '614510', 'Лесной', 'Маяковского', '47'),
  (6, '410542', 'Лесной', 'Светлая', '46'),
  (7, '620839', 'Лесной', 'Цветочная', '8'),
  (8, '443890', 'Лесной', 'Коммунистическая', '1'),
  (9, '603379', 'Лесной', 'Спортивная', '46'),
  (10, '603721', 'Лесной', 'Гоголя', '41'),
  (11, '410172', 'Лесной', 'Северная', '13'),
  (12, '614611', 'Лесной', 'Молодежная', '50'),
  (13, '454311', 'Лесной', 'Новая', '19'),
  (14, '660007', 'Лесной', 'Октябрьская', '19'),
  (15, '603036', 'Лесной', 'Садовая', '4'),
  (16, '394060', 'Лесной', 'Фрунзе', '43'),
  (17, '410661', 'Лесной', 'Школьная', '50'),
  (18, '625590', 'Лесной', 'Коммунистическая', '20'),
  (19, '625683', 'Лесной', '8 Марта', NULL),
  (20, '450983', 'Лесной', 'Комсомольская', '26'),
  (21, '394782', 'Лесной', 'Чехова', '3'),
  (22, '603002', 'Лесной', 'Дзержинского', '28'),
  (23, '450558', 'Лесной', 'Набережная', '30'),
  (24, '344288', 'Лесной', 'Чехова', '1'),
  (25, '614164', 'Лесной', 'Степная', '30'),
  (26, '394242', 'Лесной', 'Коммунистическая', '43'),
  (27, '660540', 'Лесной', 'Солнечная', '25'),
  (28, '125837', 'Лесной', 'Шоссейная', '40'),
  (29, '125703', 'Лесной', 'Партизанская', '49'),
  (30, '625283', 'Лесной', 'Победы', '46'),
  (31, '614753', 'Лесной', 'Полевая', '35'),
  (32, '426030', 'Лесной', 'Маяковского', '44'),
  (33, '450375', 'Лесной', 'Клубная', '44'),
  (34, '625560', 'Лесной', 'Некрасова', '12'),
  (35, '630201', 'Лесной', 'Комсомольская', '17'),
  (36, '190949', 'Лесной', 'Мичурина', '26');

INSERT INTO `shoeshop`.`users` VALUES
  (1, 'Никифорова Весения Николаевна', '94d5ous@gmail.com', 'uzWC67', 1),
  (2, 'Сазонов Руслан Германович', 'uth4iz@mail.com', '2L6KZG', 1),
  (3, 'Одинцов Серафим Артёмович', 'yzls62@outlook.com', 'JlFRCZ', 1),
  (4, 'Степанов Михаил Артёмович', '1diph5e@tutanota.com', '8ntwUp', 2),
  (5, 'Ворсин Петр Евгеньевич', 'tjde7c@yahoo.com', 'YOyhfR', 2),
  (6, 'Старикова Елена Павловна', 'wpmrc3do@tutanota.com', 'RSbvHv', 2),
  (7, 'Михайлюк Анна Вячеславовна', '5d4zbu@tutanota.com', 'rwVDh9', 3),
  (8, 'Ситдикова Елена Анатольевна', 'ptec8ym@yahoo.com', 'LdNyos', 3),
  (9, 'Ворсин Петр Евгеньевич', '1qz4kw@mail.com', 'gynQMT', 3),
  (10, 'Старикова Елена Павловна', '4np6se@mail.com', 'AtnDjr', 3);

INSERT INTO `shoeshop`.`products` VALUES
  (1, 'А112Т4', 'Ботинки', 'шт.', 4990, 3, 6, 'Женские Ботинки демисезонные kari', '1.jpg', 1, 1, 1),
  (2, 'F635R4', 'Ботинки', 'шт.', 3244, 2, 13, 'Ботинки Marco Tozzi женские демисезонные, размер 39, цвет бежевый', '2.jpg', 1, 2, 2),
  (3, 'H782T5', 'Туфли', 'шт.', 4499, 4, 5, 'Туфли kari мужские классика MYZ21AW-450A, размер 43, цвет: черный', '3.jpg', 2, 1, 1),
  (4, 'G783F5', 'Ботинки', 'шт.', 5900, 2, 8, 'Мужские ботинки Рос-Обувь кожаные с натуральным мехом', '4.jpg', 2, 4, 1),
  (5, 'J384T6', 'Ботинки', 'шт.', 3800, 2, 16, 'B3430/14 Полуботинки мужские Rieker', '5.jpg', 2, 6, 2),
  (6, 'D572U8', 'Кроссовки', 'шт.', 4100, 3, 6, '129615-4 Кроссовки мужские', '6.jpg', 2, 4, 2),
  (7, 'F572H7', 'Туфли', 'шт.', 2700, 2, 14, 'Туфли Marco Tozzi женские летние, размер 39, цвет черный', '7.jpg', 1, 2, 1),
  (8, 'D329H3', 'Полуботинки', 'шт.', 1890, 4, 4, 'Полуботинки Alessio Nesca женские 3-30797-47, размер 37, цвет: бордовый', '8.jpg', 1, 5, 2),
  (9, 'B320R5', 'Туфли', 'шт.', 4300, 2, 6, 'Туфли Rieker женские демисезонные, размер 41, цвет коричневый', '9.jpg', 1, 6, 1),
  (10, 'G432E4', 'Туфли', 'шт.', 2800, 3, 15, 'Туфли kari женские TR-YR-413017, размер 37, цвет: черный', '10.jpg', 1, 1, 1),
  (11, 'S213E3', 'Полуботинки', 'шт.', 2156, 3, 6, '407700/01-01 Полуботинки мужские CROSBY', NULL, 2, 3, 2),
  (12, 'E482R4', 'Полуботинки', 'шт.', 1800, 2, 14, 'Полуботинки kari женские MYZ20S-149, размер 41, цвет: черный', NULL, 1, 1, 1),
  (13, 'S634B5', 'Кеды', 'шт.', 5500, 3, 0, 'Кеды Caprice мужские демисезонные, размер 42, цвет черный', NULL, 2, 3, 2),
  (14, 'K345R4', 'Полуботинки', 'шт.', 2100, 2, 3, '407700/01-02 Полуботинки мужские CROSBY', NULL, 2, 3, 2),
  (15, 'O754F4', 'Туфли', 'шт.', 5400, 4, 18, 'Туфли женские демисезонные Rieker артикул 55073-68/37', NULL, 1, 6, 2),
  (16, 'G531F4', 'Ботинки', 'шт.', 6600, 12, 9, 'Ботинки женские зимние ROMER арт. 893167-01 Черный', NULL, 1, 1, 1),
  (17, 'J542F5', 'Тапочки', 'шт.', 500, 13, 0, 'Тапочки мужские Арт.70701-55-67син р.41', NULL, 2, 1, 1),
  (18, 'B431R5', 'Ботинки', 'шт.', 2700, 2, 5, 'Мужские кожаные ботинки/мужские ботинки', NULL, 2, 6, 2),
  (19, 'P764G4', 'Туфли', 'шт.', 6800, 15, 15, 'Туфли женские, ARGO, размер 38', NULL, 1, 3, 1),
  (20, 'C436G5', 'Ботинки', 'шт.', 10200, 15, 9, 'Ботинки женские, ARGO, размер 40', NULL, 1, 5, 1),
  (21, 'F427R5', 'Ботинки', 'шт.', 11800, 15, 11, 'Ботинки на молнии с декоративной пряжкой FRAU', NULL, 1, 6, 2),
  (22, 'N457T5', 'Полуботинки', 'шт.', 4600, 3, 13, 'Полуботинки Ботинки черные зимние, мех', NULL, 1, 3, 1),
  (23, 'D364R4', 'Туфли', 'шт.', 12400, 16, 5, 'Туфли Luiza Belly женские Kate-lazo черные из натуральной замши', NULL, 1, 1, 1),
  (24, 'S326R5', 'Тапочки', 'шт.', 9900, 17, 15, 'Мужские кожаные тапочки "Профиль С.Дали"', NULL, 2, 3, 2),
  (25, 'L754R4', 'Полуботинки', 'шт.', 1700, 2, 7, 'Полуботинки kari женские WB2020SS-26, размер 38, цвет: черный', NULL, 1, 1, 1),
  (26, 'M542T5', 'Кроссовки', 'шт.', 2800, 18, 3, 'Кроссовки мужские TOFA', NULL, 2, 6, 2),
  (27, 'D268G5', 'Туфли', 'шт.', 4399, 3, 12, 'Туфли Rieker женские демисезонные, размер 36, цвет коричневый', NULL, 1, 6, 2),
  (28, 'T324F5', 'Сапоги', 'шт.', 4699, 2, 5, 'Сапоги замша Цвет: синий', NULL, 1, 3, 1),
  (29, 'K358H6', 'Тапочки', 'шт.', 599, 20, 2, 'Тапочки мужские син р.41', NULL, 2, 6, 1),
  (30, 'H535R5', 'Ботинки', 'шт.', 2300, 2, 7, 'Женские Ботинки демисезонные', NULL, 1, 6, 2);

INSERT INTO `shoeshop`.`orders` VALUES
  (1, '2025-02-27', '2025-04-20', 1, 4, '901', 1),
  (2, '2022-09-28', '2025-04-21', 11, 1, '902', 1),
  (3, '2025-03-21', '2025-04-22', 2, 2, '903', 1),
  (4, '2025-02-20', '2025-04-23', 11, 3, '904', 1),
  (5, '2025-03-17', '2025-04-24', 2, 4, '905', 1),
  (6, '2025-03-01', '2025-04-25', 15, 1, '906', 1),
  (7, '2025-03-30', '2025-04-26', 3, 2, '907', 1),
  (8, '2025-03-31', '2025-04-27', 19, 3, '908', 2),
  (9, '2025-04-02', '2025-04-28', 5, 4, '909', 2),
  (10, '2025-04-03', '2025-04-29', 19, 4, '910', 2);

INSERT INTO `shoeshop`.`prodorders` VALUES
  (1, 1, 1, 2),
  (2, 1, 2, 2),
  (3, 2, 3, 1),
  (4, 2, 4, 1),
  (5, 3, 5, 10),
  (6, 3, 6, 10),
  (7, 4, 7, 5),
  (8, 4, 8, 4),
  (9, 5, 1, 2),
  (10, 5, 2, 2),
  (11, 6, 3, 1),
  (12, 6, 4, 1),
  (13, 7, 5, 10),
  (14, 7, 6, 10),
  (15, 8, 7, 5),
  (16, 8, 8, 4),
  (17, 9, 9, 5),
  (18, 9, 10, 1),
  (19, 10, 11, 5),
  (20, 10, 12, 5);

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
